package com.employeemanagement.Employee.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.employeemanagement.Employee.entity.Employee;
import com.employeemanagement.Employee.repository.EmployeeRepository;

@Service
public class EmployeeServiceImpl implements EmployeeService {

	
@Autowired
EmployeeRepository employeeRepository;
	
	@Override
	public List<Employee> findall() {
		// TODO Auto-generated method stub
		return employeeRepository.findAll();
	}

	@Override
	public String addEmployee(Employee emp) {
		// TODO Auto-generated method stub
		employeeRepository.save(emp);
		return "Employee Details added successfully";
	}

	@Override
	public String updateEmployee(Employee emp, int emp_id) {
		// TODO Auto-generated method stub
		Optional<Employee> cont=employeeRepository.findById(emp_id);
		if(cont.isPresent()) {
			Employee e=cont.get();
			e.setEmp_name(emp.getEmp_name());
			e.setAddress(emp.getAddress());
			employeeRepository.save(emp);
			return "Employee Details upadted with id"+emp_id;
		}
		
		
		else {
			return "Employee Details with Id not found";
		}
	}

	@Override
	public String deleteEmployee(int emp_id) {
		// TODO Auto-generated method stub
		Optional<Employee> cont=employeeRepository.findById(emp_id);
		if(cont.isPresent()) {
			Employee e=cont.get();
			employeeRepository.delete(e);
			return "Employee Details deleted with id"+ emp_id;
		}
		else {
			return "Employee Details with Id not found";
		}
		
	}

	@Override
	public Employee findId(int emp_id) {
		// TODO Auto-generated method stub
		return employeeRepository.findById(emp_id).get();
	}

}
