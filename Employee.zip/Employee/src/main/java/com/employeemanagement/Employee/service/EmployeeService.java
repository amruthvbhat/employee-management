package com.employeemanagement.Employee.service;

import java.util.List;

import com.employeemanagement.Employee.entity.Employee;

public interface EmployeeService {

	public List<Employee> findall();
	public String addEmployee(Employee emp);
	public String updateEmployee(Employee emp,int emp_id);
	public String deleteEmployee(int emp_id);
	public Employee findId(int emp_id);
	
}
